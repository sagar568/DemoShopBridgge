﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge
{
    public class DbService
    {
        ResponseMessage RM = new ResponseMessage();
        private readonly IConfiguration configuration;
        private readonly string connectionString;

        public DbService(IConfiguration configuration,ResponseMessage rm)
        {
            this.RM = rm;
            this.configuration = configuration;
            this.connectionString = configuration.GetConnectionString("SqlConnectionString");
            
        }

        public ResponseMessage AddItem(ResultData RD)
        {
            
            foreach (var item in RD.Item)
            {
                if (item.Name == null )
                {
                    RM.Status = false;
                    RM.Data = "";
                    RM.Message = "Name should not be blank.";
                    return RM;
                }

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand myCommand = new SqlCommand("SP_Product_AU", con);
                    myCommand.CommandType = CommandType.StoredProcedure;

                    myCommand.Parameters.AddWithValue("@ID", item.ID);
                    myCommand.Parameters.AddWithValue("@ProductCode", item.ProductCode);
                    myCommand.Parameters.AddWithValue("@Name", item.Name);
                    myCommand.Parameters.AddWithValue("@Description", item.Description);
                    myCommand.Parameters.AddWithValue("@Price", item.Price);                    
                    myCommand.Parameters.AddWithValue("@Status", item.Status);

                    myCommand.Parameters.AddWithValue("@Method", "AddProduct");

                    myCommand.Connection = con;
                    con.Open();
                    string result = (string)myCommand.ExecuteScalar();
                    con.Close();

                    RM.Status = true;
                    RM.Data = result;
                    RM.Message = result != "Success" ? "Duplicate Data" : "Data Pushed Successfully.";

                    return RM;
                }
            }
            return RM;
        }

        public ResponseMessage UpdateItem(ResultData RD)
        {

            foreach (var item in RD.Item)
            {
                if (item.Name == null)
                {
                    RM.Status = false;
                    RM.Data = "";
                    RM.Message = "Name should not be blank.";
                    return RM;
                }

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand myCommand = new SqlCommand("SP_Product_AU", con);
                    myCommand.CommandType = CommandType.StoredProcedure;

                    myCommand.Parameters.AddWithValue("@ID", item.ID);
                    myCommand.Parameters.AddWithValue("@ProductCode", item.ProductCode);
                    myCommand.Parameters.AddWithValue("@Name", item.Name);
                    myCommand.Parameters.AddWithValue("@Description", item.Description);
                    myCommand.Parameters.AddWithValue("@Price", item.Price);
                    myCommand.Parameters.AddWithValue("@Status", item.Status);

                    myCommand.Parameters.AddWithValue("@Method", "UpdateProduct");

                    myCommand.Connection = con;
                    con.Open();
                    string result = (string)myCommand.ExecuteScalar();
                    con.Close();

                    RM.Status = true;
                    RM.Data = result;
                    RM.Message = result != "Success" ? "Duplicate Data" : "Data Pushed Successfully.";

                    return RM;
                }
            }
            return RM;
        }

        public DataTable GetAllItem(int ID=0)
        {
            DataTable dt=new DataTable();
            SqlDataAdapter da = new SqlDataAdapter();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand myCommand = new SqlCommand("SP_GetDel_Data", con);
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@ID", ID);
                myCommand.Parameters.AddWithValue("@Method", "ALL");
                myCommand.Connection = con;
                    con.Open();

                da.SelectCommand= myCommand;
                da.Fill(dt);
                con.Close();
                }
            
            return dt;
        }

        public DataTable DelItem(clsProduct objproduct)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand myCommand = new SqlCommand("SP_GetDel_Data", con);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.Parameters.AddWithValue("@ID", objproduct.ProductID);
                myCommand.Parameters.AddWithValue("@Method", "Delete");
                myCommand.Connection = con;
                con.Open();

                da.SelectCommand = myCommand;
                da.Fill(dt);
                con.Close();
            }

            return dt;
        }


    }
}

﻿using DnsClient;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RestServiceController : ControllerBase
    {
        DbService DbService1;
        ResponseMessage RM;

        private readonly IConfiguration configuration;


        public RestServiceController(IConfiguration configuration, DbService dbService2, ResponseMessage rm)
        {
            this.DbService1 = dbService2;
            this.configuration = configuration;
            this.RM = rm;

        }

        [HttpPost("AddProduct")]
        public IActionResult AddProduct(ResultData RD)
        {


            try
            {

                if (RD.Item.Length != 0)
                {
                    RM = DbService1.AddItem(RD);
                    return Ok(RM);
                }
                else
                {
                    RM.Status = false;
                    RM.Data = "";
                    RM.Message = "Items not found.";
                    return Ok(RM);
                }

            }
            catch (Exception ex)
            {
                RM.Status = false;
                RM.Message = ex.Message;
                return Ok(RM);

            }
        }

        [HttpPost("UpdateProduct")]
        public IActionResult UpdateItem(ResultData RD)
        {


            try
            {

                if (RD.Item.Length != 0)
                {
                    RM = DbService1.UpdateItem(RD);
                    return Ok(RM);
                }
                else
                {
                    RM.Status = false;
                    RM.Data = "";
                    RM.Message = "Items not found.";
                    return Ok(RM);
                }

            }
            catch (Exception ex)
            {
                RM.Status = false;
                RM.Message = ex.Message;
                return Ok(RM);

            }
        }

        [HttpGet("AllItem")]
        public IActionResult GetAllItem(int ID)
        {
            try
            {

                DataTable dt = DbService1.GetAllItem(ID);
                string JSONString = string.Empty;
                JSONString = JsonConvert.SerializeObject(dt);
                return Ok(dt);


            }
            catch (Exception ex)
            {
                RM.Status = false;
                RM.Message = ex.Message;
                return Ok(RM);

            }
        }

        [HttpPost("DeleteProduct")]
        public IActionResult DelProduct(clsProduct objProduct)
        {
            try
            {

                DataTable dt = DbService1.DelItem(objProduct);
                string JSONString = string.Empty;
                JSONString = JsonConvert.SerializeObject(dt);
                return Ok(dt);

            }
            catch (Exception ex)
            {
                RM.Status = false;
                RM.Message = ex.Message;
                return Ok(RM);

            }
        }


    }
}

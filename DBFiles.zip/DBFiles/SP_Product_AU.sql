Alter Proc SP_Product_AU

	 @ID int
	,@ProductCode varchar(50)
	,@Name varchar(100)
	,@Description varchar(500)
	,@Price varchar(50)=0
	,@Status smallint=0
	,@Method varchar(50)=''

as


BEGIN
Declare @Result varchar(20)='';
	if(@Method='AddProduct')
		begin
		if not exists(Select 0 from tblInventory Where ID=@ID)
			begin
			 Insert into tblInventory Values(@ProductCode,@Name,@Description,@Price,@Status,GETDATE(),null);
			 set @Result='Success'
			end
		 else
		 set @Result='Duplicate Record'
		end

	if(@Method='UpdateProduct')
		begin
		 if exists(Select 0 from tblInventory Where ID=@ID)
			begin
				Update tblInventory set ProductCode=@ProductCode,
				Name=@Name,
				Description=@Description,
				Price=@Price,
				Status=@Status,
				UpdatedOn=GETDATE() Where ID=@ID;
				set @Result='Success'
			end
		 else
		 set @Result='Duplicate Record'		
		end

Select @Result;
END
USE [master]
GO
/****** Object:  Database [dbShopBridge]    Script Date: 02-12-2021 05:29:38 PM ******/
CREATE DATABASE [dbShopBridge]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'dbShopBridge', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\dbShopBridge.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'dbShopBridge_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\dbShopBridge_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [dbShopBridge] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [dbShopBridge].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [dbShopBridge] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [dbShopBridge] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [dbShopBridge] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [dbShopBridge] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [dbShopBridge] SET ARITHABORT OFF 
GO
ALTER DATABASE [dbShopBridge] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [dbShopBridge] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [dbShopBridge] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [dbShopBridge] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [dbShopBridge] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [dbShopBridge] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [dbShopBridge] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [dbShopBridge] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [dbShopBridge] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [dbShopBridge] SET  DISABLE_BROKER 
GO
ALTER DATABASE [dbShopBridge] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [dbShopBridge] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [dbShopBridge] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [dbShopBridge] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [dbShopBridge] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [dbShopBridge] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [dbShopBridge] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [dbShopBridge] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [dbShopBridge] SET  MULTI_USER 
GO
ALTER DATABASE [dbShopBridge] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [dbShopBridge] SET DB_CHAINING OFF 
GO
ALTER DATABASE [dbShopBridge] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [dbShopBridge] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [dbShopBridge] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [dbShopBridge] SET QUERY_STORE = OFF
GO
USE [dbShopBridge]
GO
/****** Object:  Table [dbo].[tblInventory]    Script Date: 02-12-2021 05:29:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblInventory](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ProductCode] [varchar](50) NULL,
	[Name] [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[Price] [varchar](10) NOT NULL,
	[Status] [smallint] NULL,
	[CreatedOn] [datetime2](7) NULL,
	[UpdatedOn] [datetime2](7) NULL,
 CONSTRAINT [PK_tblInventory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[SP_GetDel_Data]    Script Date: 02-12-2021 05:29:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--Exec SP_GetDel_Data 0,'ALL'

CREATE Proc [dbo].[SP_GetDel_Data]

@ID bigint=0,
@Method varchar(30)=''
as

BEGIN
 IF(@ID!=0 and @Method='Delete' )
	begin
	 Delete From tblInventory Where ID=@ID
	 Select 'Record Deleted Successfully'
	end

else
 begin
  if(@ID>0)
  Select 
  ID
	,ProductCode
	,Name
	,Description
	,Price
	,Status
	,CONVERT(VARCHAR(10), CreatedOn, 103) as CreatedOn
	,ISnull(CONVERT(VARCHAR(10), UpdatedOn, 103),'') as UpdatedOn
	from tblInventory where ID=@ID
  else
	Select 
	ID
	,ProductCode
	,Name
	,Description
	,Price
	,Status
	,CONVERT(VARCHAR(10), CreatedOn, 103) as CreatedOn
	,ISnull(CONVERT(VARCHAR(10), UpdatedOn, 103),'') as UpdatedOn from tblInventory
 end
END
GO
/****** Object:  StoredProcedure [dbo].[SP_Product_AU]    Script Date: 02-12-2021 05:29:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Proc [dbo].[SP_Product_AU]

	 @ID int
	,@ProductCode varchar(50)
	,@Name varchar(100)
	,@Description varchar(500)
	,@Price varchar(50)=0
	,@Status smallint=0
	,@Method varchar(50)=''

as


BEGIN
Declare @Result varchar(20)='';
	if(@Method='AddProduct')
		begin
		if not exists(Select 0 from tblInventory Where ID=@ID)
			begin
			 Insert into tblInventory Values(@ProductCode,@Name,@Description,@Price,@Status,GETDATE(),null);
			 set @Result='Success'
			end
		 else
		 set @Result='Duplicate Record'
		end

	if(@Method='UpdateProduct')
		begin
		 if exists(Select 0 from tblInventory Where ID=@ID)
			begin
				Update tblInventory set ProductCode=@ProductCode,
				Name=@Name,
				Description=@Description,
				Price=@Price,
				Status=@Status,
				UpdatedOn=GETDATE() Where ID=@ID;
				set @Result='Success'
			end
		 else
		 set @Result='Duplicate Record'		
		end

Select @Result;
END
GO
USE [master]
GO
ALTER DATABASE [dbShopBridge] SET  READ_WRITE 
GO

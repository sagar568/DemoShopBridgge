
--Exec SP_GetDel_Data 0,'ALL'

Alter Proc SP_GetDel_Data

@ID bigint=0,
@Method varchar(30)=''
as

BEGIN
 IF(@ID!=0 and @Method='Delete' )
	begin
	 Delete From tblInventory Where ID=@ID
	 Select 'Record Deleted Successfully'
	end

else
 begin
  if(@ID>0)
  Select 
  ID
	,ProductCode
	,Name
	,Description
	,Price
	,Status
	,CONVERT(VARCHAR(10), CreatedOn, 103) as CreatedOn
	,ISnull(CONVERT(VARCHAR(10), UpdatedOn, 103),'') as UpdatedOn
	from tblInventory where ID=@ID
  else
	Select 
	ID
	,ProductCode
	,Name
	,Description
	,Price
	,Status
	,CONVERT(VARCHAR(10), CreatedOn, 103) as CreatedOn
	,ISnull(CONVERT(VARCHAR(10), UpdatedOn, 103),'') as UpdatedOn from tblInventory
 end
END